# Landing Rifa DIRECOM (v2) — lista para enviar

## Ya incluye:
- Logo DIRECOM correcto
- Imagen real de desbrozadora (premio)
- Imagen de carreta Tornado
- QR a redes
- Registro (abre WhatsApp con mensaje listo)
- Vigencia: 1–30 de marzo
- Conteo regresivo al sorteo (30 de marzo 6:00 pm)

## ÚNICO CAMBIO OBLIGATORIO
Abre `script.js` y cambia:
- whatsappDestino: "50400000000"  -> pon el número real de WhatsApp DIRECOM

## Publicar rápido (Netlify gratis)
1) Entra a Netlify
2) Add new site -> Deploy manually
3) Arrastra la carpeta completa (descomprimida)
4) Copia el link que te da Netlify y envíalo a clientes.
